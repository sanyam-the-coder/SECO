# Shareiki.github.io
A Charity organization that is trying to help local communities around Mombasa Kenya, deal with hunger and insufficient food in the region.
